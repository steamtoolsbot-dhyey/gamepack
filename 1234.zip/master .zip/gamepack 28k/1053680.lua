-- 1053680's Lua and Manifest Created by Morrenus
-- Granny Simulator
-- Created: September 29, 2025 at 15:19:59 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1053680) -- Granny Simulator
-- MAIN APP DEPOTS
addappid(1053681, 1, "c6aed26c3e0ae48aa7358a1fa5da6e0e862a29c350f9b2f13fd067993129a454") -- Granny Simulator Depot Windows
setManifestid(1053681, "6950094035752429168", 2944513345)