-- Downloaded using DepotBox - https://depotbox.org/
-- Original file: 1039100.lua
addappid(1039100)
addappid(1039101,0,"5a240d10cf8b787bba2e756cb262c5b4fee826f9664cba84e8c8ca4f637bc936")
setManifestid(1039101,"8542429291116129042")
addappid(1039102,0,"ad7e130e498834c174e7c0fd9ccdf5ee5613a3de80841a2ce16bd7c1bd147419")
setManifestid(1039102,"5511553202140067414")